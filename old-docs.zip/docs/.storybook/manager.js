import { addons } from '@storybook/addons';
import blendTheme from './theme/blend';

addons.setConfig({
  theme: blendTheme,
});