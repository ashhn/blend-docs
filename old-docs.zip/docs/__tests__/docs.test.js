'use strict';

const docs = require('..');

describe('@blend-ui/docs', () => {
    it('needs tests');
});
