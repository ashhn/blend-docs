import React from "react";

export default { title: "Test" };

export const box = () => <div>Testing...</div>;
box.story = {
  name: "Test",
};
